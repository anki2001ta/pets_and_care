export const GET_SLIDESHOW_REQUEST = 'GET_SLIDESHOW_REQUEST';
export const GET_SLIDESHOW_SUCCESS = 'GET_SLIDESHOW_SUCCESS';
export const GET_SLIDESHOW_FAILURE = 'GET_SLIDESHOW_FAILURE';
export const GET_Food_SLIDESHOW_SUCCESS='GET_Food_SLIDESHOW_SUCCESS';
// cats product page
export const GET_Product_REQUEST = 'GET_Product_REQUEST';
export const GET_Product_cat_SUCCESS = 'GET_Product_cat_SUCCESS';
export const GET_Product_FAILURE = 'GET_Product_FAILURE';
//dog sucess
export const GET_Product_dog_SUCCESS = 'GET_Product_dog_SUCCESS';
//bird
export const GET_Product_bird_SUCCESS = 'GET_Product_bird_SUCCESS';
//rabbit
export const GET_Product_rabbit_SUCCESS = 'GET_Product_rabbit_SUCCESS';

export const GET_User_SUCCESS = 'GET_User_SUCCESS';
export const GET_SEARCH_SUCCESS='GET_SEARCH_SUCCESS'