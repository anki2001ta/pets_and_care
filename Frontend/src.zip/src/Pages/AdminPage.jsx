import React from 'react'

const AdminPage = () => {
  return (
    <div>AdminPage</div>
  )
}

export default AdminPage