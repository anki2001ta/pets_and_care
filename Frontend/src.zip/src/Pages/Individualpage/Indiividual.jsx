import React from 'react'

const Individual = () => {
  return (
    <div>Indiividual</div>
  )
}

export default Individual