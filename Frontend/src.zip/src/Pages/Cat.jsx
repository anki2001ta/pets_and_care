import React from 'react'
import cats from "./cat.css"
const Cat = () => {
  return (
    <div id="roots">
        <div class="container move">
        <div class="cat walking"></div>
      </div>
    </div>
  )
}

export default Cat