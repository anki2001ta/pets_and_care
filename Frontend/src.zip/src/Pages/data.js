export const countries = [
    {
      image: "https://cdn.shopify.com/s/files/1/1199/8502/files/walking_essential_4_1920x.png?v=1669010018",
      
    },
    {
      image: "https://cdn.shopify.com/s/files/1/1199/8502/files/tags_banner_1920x.png?v=1671707208",
      
    },
    {
      image: "https://cdn.shopify.com/s/files/1/1199/8502/files/whiskas_banner_1920x.png?v=1671598548",
      
    },
    {
      image: "https://cdn.shopify.com/s/files/1/1199/8502/files/Bed_Banner_1.jpg?v=1667887437",
      
    }
    
  ];